const boggle_solver = require('/home/codio/workspace/Boggle_Testing/boggle_solver.js');

/** Lowercases a string array in-place. (Used for case-insensitive string array
 *  matching).
 * @param {string[]} stringArray - String array to be lowercase.
 */
function lowercaseStringArray(stringArray) {
  for (let i = 0; i < stringArray.length; i++)
    stringArray[i] = stringArray[i].toLowerCase();
}

describe('Boggle Solver tests suite:', () => {
  describe('Normal input', () => {

    test('2x2 Input', () => {
      let grid = [  ['P', 'D'],
                    ['E', 'I']];
      let dictionary = ['pie','eei','ei','die'];
      let expected = ['pie','die'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });

    test('3x3 Input', () => {
      let grid = [ ['V','L','H'],
                   ['O','D','A'],
                   ['Y','G','U']];
      let dictionary = ['mail','dog','lock','lag','aloof','chair','had'];
      let expected = ['dog','had','lag'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });

    test('4x4 Input', () => {
      let grid = [ ['A','D','P','C'],
                   ['L','Z','T','V'],
                   ['H','F','A','I'],
                   ['M','P','T','J']];
      let dictionary = ['fit','lad','fist','weed','fat','pat','track','vat','class','bug'];
      let expected = ['lad','fat','pat','vat'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });

    test('No Solution', () => {
      let grid = [ ['H','V','E'],
                   ['R','G','X'],
                   ['I','Z','T']];
      let dictionary = ['spot','get','study','tire','rex','egg','name','owe'];
      let expected = [];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
  });

  
  describe('Problem contraints', () => {
    // Cases such as Qu
    
    test('2x2 Input with Qu and St', () => {
      let grid = [  ['Qu', 'R'],
                    ['A', 'St']];
      let dictionary = ['quar','qua','stra','qust','st','qu','aqua'];
      let expected = ['quar','qua','stra','qust'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
    
    test('3x3 Input with Qu and St', () => {
      let grid = [ ['C','I','T'],
                   ['Qu','L','N'],
                   ['L','A','St']];
      let dictionary = ['last','cut','grip','lint','paint','quill','stall','clan','width','tin'];
      let expected = ['last','lint','quill','stall','clan','tin'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
    
    test('Ignore Words Ending with Q', () => {
      let grid = [ ['Qu','L','T'],
                   ['J','I','L'],
                   ['T','A','F']];
      let dictionary = ['jail','jailq','jailqu','tail','tailq','fail','failq','fill','fillq'];
      let expected = ['jail','jailqu','tail','fail','fill'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
    
    test('One Word Cannot Use A Cube More Than Once', () => {
      let grid = [ ['C','I','T'],
                   ['P','L','N'],
                   ['F','A','St']];
      let dictionary = ['pil','pill','tin','tint','fal','fall','stal','stall'];
      let expected = ['pil','tin','fal','stal'];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);
      
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
  });

  
  describe('Input edge cases', () => {

    // Example Test using Jess
    test('Dictionary is empty', () => {
      // (Edge case) Since there are no possible solutiona, it should return an
      // empty list.
      let grid = [['A', 'B', 'C', 'D'],
                    ['E', 'F', 'G', 'H'],
                    ['I', 'J', 'K', 'L'],
                    ['M', 'N', 'O', 'P']];
      let dictionary = [];
      let expected = [];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);

      // Lowercasing for case-insensitive string array matching.
      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
    
    test('Grid is empty', () => {
      let grid = [];
      let dictionary = ['ear','fold','he','calm','poem'];
      let expected = [];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);

      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
    
    test('1x1 Grid', () => {
      let grid = [['E']];
      let dictionary = ['snow','score','arrow','hill','cruel'];
      let expected = [];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);

      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
    
    test('0x0 Grid', () => {
      let grid = [[]];
      let dictionary = ['have','wheel','test','aid','mayor'];
      let expected = [];

      let solutions = boggle_solver.findAllSolutions(grid, dictionary);

      lowercaseStringArray(solutions);
      lowercaseStringArray(expected);
      expect(solutions.sort()).toEqual(expected.sort());
    });
  });
});
